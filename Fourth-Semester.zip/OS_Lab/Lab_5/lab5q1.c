/*Write a C program to create a child process. Display different messages in parent
process and child process. Display PID and PPID of both parent and child process.*/
#include<stdio.h>
#include<unistd.h>
int main()
{
  pid_t fork_return;
  fork_return=fork();
  if(fork_return<0)
  {
     printf("The child process failed!");
  }
  else if(fork_return==0)
  {
     printf("\nIn child process\n");
     printf("PID: %d\n", getpid());
     printf("Parent's PID: %d\n", getppid());
  }
  else
  {
     printf("In parent process\n");
     printf("PID: %d\n", getpid());
     printf("Parent's PID: %d\n", getppid());
  }
  return 0;
}

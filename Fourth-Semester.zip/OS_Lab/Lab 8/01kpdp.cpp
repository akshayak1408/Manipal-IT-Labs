#include<iostream>
using namespace std;

int maxk(int a,int b){
  return (a>b)?a:b;
}

int knapsack(int w[],int p[], int n, int c){
 int i,j;
 int k[n+1][c+1];
 for(i=0;i<=n;i++){
    for(j=0; j<=c;j++){
    
        if(i==0 || c==0)
        k[i][j]=0;
        else if(w[i-1]<=j)
            k[i][j]=maxk(p[i-1]+ k[i-1][j-w[i-1]],k[i-1][j]);
        else k[i][j]=k[i-1][j];
 }
 }
 
 /*
 for(i=0;i<=n;i++){

   for(j=0;j<=n;j++){
      cout<<k[i][j]<<" ";
 }
 cout<<endl;
 } */
 return k[n][c];
}


int main(){

int c,w[30],n,p[30];

cout<<"Enter the capacity";
cin>>c;

cout<<"Enter the number of weights";
cin>>n;

cout<<"Enter the weights";

for(int i=0;i<n;i++)
cin>>w[i];

cout<<"Enter the profits";
for(int i=0;i<n;i++)
cin>>p[i];

cout<<"total profit:"<< knapsack(w,p,n,c);



}

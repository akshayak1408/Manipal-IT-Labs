#!/bin/bash
cp $1 $2
echo "Done"
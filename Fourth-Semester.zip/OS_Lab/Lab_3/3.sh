#!/bin/bash 
echo "Replaced .txt to .text"
result=`find . -depth -name *.txt`
for i in $result 
do
    mv $i ${i%.txt}.text
done
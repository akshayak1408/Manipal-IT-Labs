echo "Enter a file or directory"
read x

if [ -d "${x}" ]; then
	echo "$x is a directory";
else
	if [ -f "${x}" ]; then
		echo "${x} is a file";
	else
		echo "${x} is not valid"
		exit 1
	fi
fi

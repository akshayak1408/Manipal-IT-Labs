echo "Enter the pattern"
read p
echo "Enter the location"
read l

echo `grep -l -r $p $l`